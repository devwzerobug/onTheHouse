OnTheHouse iOS Application

Description:
OnTheHouse is an application that is similar to craigslist, but is primarily for free items. 

Group Members:
Michael Hyun
    michael.hyun3@gmail.com
    009828299
Marta Malapitaan
    009000264
Kaanchana Allanki
    009812725
Aditya Shah
    008799297

Build Instructions:

Login using FB Login, or just click login. Click login to go to the homepage. Then, you have options of going to the post profile, edit post, account. The MapKit is implemented in the section called Post Profile, and uses Market to pinpoint the location of the user. For now, we have it with a pin at San Jose State to show we know how to put a pin down at a certain location. We also used UIKit, by using Ui elements such as UIButton, UIText Field and etc. We also used AppKit, but instead of using it for messenger, we used it for the NSScrollView. We made a scroll view using Appkit. This is under Post Profile as well. 
